import json

def get_data(filename):
    """Retrieves the parsed JSON data from the given filename"""


if __name__ == '__main__':
    data = get_data('sanderson.json')
